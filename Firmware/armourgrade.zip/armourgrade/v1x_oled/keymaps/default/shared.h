// shared.h
#ifndef SHARED_H
#define SHARED_H

extern bool dip_switch_active;

#endif // SHARED_H
