/* Copyright 2020 imchipwood
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include QMK_KEYBOARD_H



enum {
	QMK_BEST = SAFE_RANGE,
	CLOSED_TAB,
	NEW_BROWSER_WINDOW,
	NEW_TAB,
	EDGE,
	TELEGRAM,
	DYNAMIC_DC,
	AUTOSCALE,
	LAYER_INCREMENT,
	SAP_PREV_SESSION,
	TARGET_HOURS,
	BOARD_OUTLINE,
	BOARD_CUTOUT,
	Shift_Equal,
	Shift_Minus,
	POLYGON_RESTORE_ALL,
	CREATE_POLYGON,
	POLYGON_SHELVE_ALL,
	MOVE_SELECTION,
	POLYGON_REPOUR_SELECTED,
	MATHCAD_INT,
	MATHCAD_DER,
	MATHCAD_SUM,
	MATHCAD_UNITS,
	MATHCAD_ABS,
	MATHCAD_SUBSCRPT,
	MATHCAD_DEF,
	MATHCAD_BOOLEQ,
	MATHCAD_OPERATORS,
	MATHCAD_SYMBOLS,
	TEAMS_SEARCH,
	TEAMS_END_CALL,
	Stream_6,
	Stream_Top,
	VUKICA,
	VUKICA_MAIL,
	RUN_FOLDER_SCRIPT,
	TOGGLE_LAYER,
	Mute_All
	// Other declarations would go here, separated by commas, if you have them
};
int LAYER_LEVEL = 0; 
bool process_record_user(uint16_t keycode, keyrecord_t *record) {
    switch (keycode){
		case EDGE:        
				if(record->event.pressed){
					register_code(KC_F13);
				} else {
					unregister_code(KC_F13);
				}
			return false;
		case TELEGRAM:        
				if(record->event.pressed){
					SEND_STRING(SS_TAP(X_LGUI) "telegram" SS_DELAY(500) SS_TAP(X_ENT));
                    } else {
					// when keycode is released
                }
			return false;
		case LAYER_INCREMENT:        
				if(record->event.pressed){
					++LAYER_LEVEL;
         		    if (LAYER_LEVEL > 4) {
             		   LAYER_LEVEL = 0;
            		}
            	layer_move(LAYER_LEVEL);
				} 
			return true;
		case AUTOSCALE:        
				if(record->event.pressed){
					register_code(KC_F6);
				} else {
					unregister_code(KC_F6);
				}
			return false;
		case SAP_PREV_SESSION:        
				if(record->event.pressed){
					register_code(KC_LCTL);
					register_code(KC_LSFT);
					register_code(KC_F2);
				} else {
					unregister_code(KC_F2);
					unregister_code(KC_LSFT);
					unregister_code(KC_LCTL);
				}
			return false;
		case TARGET_HOURS:        
				if(record->event.pressed){
					register_code(KC_LCTL);
					register_code(KC_LSFT);
					register_code(KC_F1);
				} else {
					unregister_code(KC_F1);
					unregister_code(KC_LSFT);
					unregister_code(KC_LCTL);
				}
			return false;
		case BOARD_OUTLINE:        
			if(record->event.pressed){
				tap_code16(KC_D);
				wait_ms(30);
				tap_code16(KC_S);
				wait_ms(30);
				tap_code16(KC_D);
				//SEND_STRING(SS_TAP(X_D) SS_DELAY(50) SS_TAP(X_S) SS_DELAY(50) SS_TAP(X_D));
			} else {
				
			}
			return false;
        case BOARD_CUTOUT:        
			if(record->event.pressed){
				tap_code16(KC_T);
				wait_ms(30);
				tap_code16(KC_V);
				wait_ms(30);
				tap_code16(KC_B);
				//SEND_STRING(SS_TAP(X_T) SS_DELAY(50) SS_TAP(X_V) SS_DELAY(50) SS_TAP(X_B));
			} else {
				
			}
			return false;
		case POLYGON_RESTORE_ALL:        
			if(record->event.pressed){
				tap_code16(KC_T);
				wait_ms(30);
				tap_code16(KC_G);
				wait_ms(30);
				tap_code16(KC_E);
				//SEND_STRING(SS_TAP(X_T) SS_DELAY(50) SS_TAP(X_G) SS_DELAY(50) SS_TAP(X_E));
			} else {
				
			}
			return false;
		case POLYGON_SHELVE_ALL:        
			if(record->event.pressed){
				tap_code16(KC_T);
				wait_ms(30);
				tap_code16(KC_G);
				wait_ms(30);
				tap_code16(KC_H);
				//SEND_STRING(SS_TAP(X_T) SS_DELAY(50) SS_TAP(X_G) SS_DELAY(50) SS_TAP(X_H));
			} else {
				
			}
			return false;
		case CREATE_POLYGON:        
			if(record->event.pressed){
				tap_code16(KC_T);
				wait_ms(30);
				tap_code16(KC_V);
				wait_ms(30);
				tap_code16(KC_G);
				//SEND_STRING(SS_TAP(X_T) SS_DELAY(50) SS_TAP(X_V) SS_DELAY(50) SS_TAP(X_G));
			} else {
				
			}
			return false;
		case POLYGON_REPOUR_SELECTED:        
			if(record->event.pressed){
				tap_code16(KC_T);
				wait_ms(30);
				tap_code16(KC_G);
				wait_ms(30);
				tap_code16(KC_R);
				//SEND_STRING(SS_TAP(X_T) SS_DELAY(50) SS_TAP(X_G) SS_DELAY(50) SS_TAP(X_R));
			} else {
				
			}
			return false;
		case MOVE_SELECTION:        
			if(record->event.pressed){
				tap_code16(KC_M);
				wait_ms(30);
				tap_code16(KC_X);
				//SEND_STRING(SS_TAP(X_M) SS_DELAY(50) SS_TAP(X_X));
			} else {
				
			}
			return false;
		case MATHCAD_UNITS:        
			if(record->event.pressed){
				SEND_STRING(SS_LALT("m") SS_DELAY(30) SS_TAP(X_U));
			} else {
			}
			return false;
		case MATHCAD_OPERATORS:        
			if(record->event.pressed){
				SEND_STRING(SS_LALT("m") SS_DELAY(30) SS_TAP(X_O));
			} else {
			}
			return false;
		case MATHCAD_SYMBOLS:        
			if(record->event.pressed){
				SEND_STRING(SS_LALT("m") SS_DELAY(30) SS_TAP(X_Y));
			} else {
			}
			return false;
		case MATHCAD_ABS:        
				if(record->event.pressed){
					register_code16(KC_PIPE);

				} else {
					unregister_code16(KC_PIPE);
				}
			return false;
		case MATHCAD_DEF:        
			if(record->event.pressed){
				SEND_STRING(SS_LSFT(";"));
			} else {
			}
			return false;
		case MATHCAD_BOOLEQ:        
			if(record->event.pressed){
				SEND_STRING(SS_LCTL("="));
			} else {
			}
			return false;
		case TEAMS_SEARCH:        
			if(record->event.pressed){
				SEND_STRING(SS_LCTL("e"));
			} else {
			}
			return false;
		case VUKICA:        
			if(record->event.pressed){
				SEND_STRING("Pozdrav Vukice, zaboravio sam kartice danas, a dosao sam oko __h. Da li me mozes check in-ovati?");
			} else {
			}
			return false;
		case VUKICA_MAIL:        
			if(record->event.pressed){
				SEND_STRING("Pozdrav Vukice, po dogovoru ti saljem mail. Danas __.__.  sam zaboravio kartice a dosao sam u __h. Da li bi me mogla check in-ovati. \n Hvala u napred.");
			} else {
			}
			return false;
		case RUN_FOLDER_SCRIPT:
    		if (record->event.pressed) {
        		SEND_STRING(SS_LGUI("r") SS_DELAY(50) "C:\\python scripts\\Create_Project_Folder_Structure\\Create_Project_Folder_Structure.exe" SS_TAP(X_ENT));  // Path to the EXE
    		}else{

			}
			return false;
		case TEAMS_END_CALL:        
				if(record->event.pressed){
					register_code(KC_LCTL);
					register_code(KC_LSFT);
					register_code(KC_H);
				} else {
					unregister_code(KC_H);
					unregister_code(KC_LSFT);
					unregister_code(KC_LCTL);
				}
		case TOGGLE_LAYER:        
				if(record->event.pressed){
					register_code(KC_LCTL);
					register_code(KC_LSFT);
				
				} else {
					unregister_code(KC_LSFT);
					unregister_code(KC_LCTL);
				}
    }	
    return true;
}
const uint16_t PROGMEM keymaps[][MATRIX_ROWS][MATRIX_COLS] = {
        /*
            BASE LAYER
    /-----------------------------------------------------`
    |             |    7    |    8    |    9    |  Bkspc  |
    |             |---------|---------|---------|---------|
    |             |    4    |    5    |    6    |   Esc   |
    |             |---------|---------|---------|---------|
    |             |    1    |    2    |    3    |   Tab   |
    |-------------|---------|---------|---------|---------|
    | Play Pause  |  TT(1)  |    0    |    .    |  Enter  |
    \-----------------------------------------------------'
    */
    [2] = LAYOUT(
        BOARD_OUTLINE,      BOARD_CUTOUT,    CREATE_POLYGON,             
        POLYGON_SHELVE_ALL, POLYGON_REPOUR_SELECTED,    POLYGON_RESTORE_ALL,            
        KC_4,               KC_3,                       KC_PAST,            
        C(KC_W),    KC_ESC,    TOGGLE_LAYER
    ),
    /*
            SUB LAYER
    /-----------------------------------------------------`
    |             |         |         |         |  Reset  |
    |             |---------|---------|---------|---------|
    |             |         |         |         |    +    |
    |             |---------|---------|---------|---------|
    |             |         |         |         |    -    |
    |-------------|---------|---------|---------|---------|
    |    LOCK     |         |         |         |    =    |
    \-----------------------------------------------------'
    */
   [3] = LAYOUT(
                    UG_VALU,     UG_VALD,     KC_NO,   
                    KC_NO,     RGB_M_B,     RGB_M_X,      
                     RGB_M_R,     RGB_M_G,    RGB_M_SN,
                     KC_NO,     RGB_MODE_KNIGHT,      RGB_M_TW
	),

    [0] = LAYOUT(
        LGUI(KC_1), LGUI(KC_2), LGUI(KC_3),      
        LGUI(KC_4), LGUI(KC_5),	SGUI(KC_S),      
        LGUI(KC_6),    KC_CALCULATOR,     LGUI(KC_7),      
        RUN_FOLDER_SCRIPT,   SGUI(KC_LEFT),     KC_NO
      
    ),


    [1] = LAYOUT(
                    A(KC_1),    A(KC_4),      KC_PENT,   
                     C(KC_PPLS),     C(KC_PMNS),       AUTOSCALE,
                    KC_F3,     KC_F11,      KC_NO,
                    KC_NO,     SAP_PREV_SESSION,      TARGET_HOURS
    ),

	[4] = LAYOUT(																						//MATHCADE LAYER
                    LCTL(KC_KP_MINUS),  KC_CIRC,      KC_BACKSLASH,   //NTEGRAL DERIVATIE  SUM   C(S(KC_I)),    C(S(KC_D)),       C(S(KC_DLR)),     
                    MATHCAD_UNITS,     MATHCAD_OPERATORS,        MATHCAD_SYMBOLS,
                    MATHCAD_BOOLEQ,     KC_EQUAL,             LSFT(KC_SEMICOLON),
                    C(KC_F5),  C(KC_Q),	KC_NO
    ),
    
	[5] = LAYOUT(
                    VUKICA,    VUKICA_MAIL,      TEAMS_SEARCH,
                    KC_NO,     KC_NO,        KC_NO,
                    KC_NO,     KC_NO,             KC_NO,
                    C(S(KC_M)),     KC_NO,      TEAMS_END_CALL
    )
};

bool dip_switch_update_user(uint8_t index, bool active) {
    switch (get_highest_layer(layer_state)) {
		case 2:
			switch (index) {
        		case 0: 
            		if (active) {
                		tap_code(KC_Z);
						tap_code(KC_A);
            		} else {
                
            		}
        		return true;
				case 1: 
					if(active){
						 
					} else{

					}
		
    		}
    			return true;
		break;
		case 3:
			switch (index) {
        		case 0: 
            		if (active) {
                		rgblight_toggle();
            		} else {
                
            		}
        		return true;
				case 1: 
					if(active){

					} else{

					}
		
    		}
    			return true;
		break;
		case 5:
			switch (index) {
        		case 0: 
            		if (active) {
                		register_code(KC_LCTL);
						register_code(KC_LSFT);
						register_code(KC_M);
            		} else {
						register_code(KC_LCTL);
						register_code(KC_LSFT);
						register_code(KC_M);
            		}
        		return true;
				case 1: 
					if(active){


					} else{
						
					}
		
    		}
    			return true;
		break;
	default:
		switch (index) {
        		case 0: 
            		if (active) {
                		tap_code(KC_AUDIO_MUTE);
            		} else {
                
            		}
        		return true;
				case 1: 
					if(active){
						
					} else{
						
					}
		}
			return true;
		break;
	}			
}
