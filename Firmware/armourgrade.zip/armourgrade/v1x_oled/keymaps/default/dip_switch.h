// dip_switch.h

#ifndef DIP_SWITCH_H
#define DIP_SWITCH_H

#include <stdint.h>

// Define the pin connected to the dip switch
#define DIP_SWITCH_PIN C6 // Change this to your actual pin

// Function prototype
bool check_dip_switch(void); // Checks the state of the dip switch
void update_dip_switch_state(void); // Updates the state of the dip switch

extern bool dip_switch_pressed; // Global variable to track the dip switch state

#endif // DIP_SWITCH_H
