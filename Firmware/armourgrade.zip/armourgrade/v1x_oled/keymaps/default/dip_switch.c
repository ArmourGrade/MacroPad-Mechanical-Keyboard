// dip_switch.c

#include "dip_switch.h"
#include "quantum.h"

bool dip_switch_pressed = false; // Initialize the dip switch state variable

bool check_dip_switch(void) {
    // Read the dip switch state
    return !readPin(DIP_SWITCH_PIN); // Assuming LOW indicates pressed
}

void update_dip_switch_state(void) {
    static bool last_state = false; // Store the last state of the dip switch
    bool current_state = check_dip_switch();

    // Check for state change
    if (current_state != last_state) {
        dip_switch_pressed = current_state; // Update the pressed state
    }
    
    last_state = current_state; // Update the last state for next check
}
