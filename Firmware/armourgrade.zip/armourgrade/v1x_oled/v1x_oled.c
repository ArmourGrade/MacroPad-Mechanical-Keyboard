/* Copyright 2020 imchipwood
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */
#include "quantum.h"
#include <stdio.h>
#include "dip_switch.c"
char wpm_str[10];

#ifdef ENCODER_ENABLE
#define ENCODER_RESOLUTION 2
#define OLED_DISPLAY_128X64
//#define ENCODER_DEFAULT_POS 0x3


bool encoder_update_user(uint8_t index, bool clockwise) {
    switch (get_highest_layer(layer_state)) {
        case 3:           
    // Right encoder
            if (index == 0) {
                if (clockwise) {
                    rgblight_increase_hue();
             } else {
                    rgblight_decrease_hue();
                }
    // Left encoder
            } else if (index == 1) {
                int8_t layer = get_highest_layer(layer_state);   
                layer += clockwise ? 1 : -1;
                if (layer < 0) { layer = 0; }
                if (layer >= 6) { layer = 6 - 1; }

            clear_keyboard();  // Clear to prevent stuck keys.
            // Turn `layer` on and all others off.
            layer_move(layer);
            }
            break;
        case 2:
            if (index == 0) {
                if (clockwise) {
                    tap_code(KC_PGUP);
             } else {
                    tap_code(KC_PGDN);
                }
    // Left encoder
            } else if (index == 1) {
                int8_t layer = get_highest_layer(layer_state);   
                layer += clockwise ? 1 : -1;
                if (layer < 0) { layer = 0; }
                if (layer >= 6) { layer = 6 - 1; }
            clear_keyboard();  // Clear to prevent stuck keys.
            // Turn `layer` on and all others off.
            layer_move(layer);
            }
            break;
        default:
            if (index == 0) {
                if (clockwise) {
                    tap_code(KC_VOLU);
             } else {
                    tap_code(KC_VOLD);
                }
    // Left encoder
            } else if (index == 1) {
                int8_t layer = get_highest_layer(layer_state);   
                layer += clockwise ? 1 : -1;
                if (layer < 0) { layer = 0; }
                if (layer >= 6) { layer = 6 - 1; }

            clear_keyboard();  // Clear to prevent stuck keys.
            // Turn `layer` on and all others off.
            layer_move(layer);
            }
            break;
    }
    return false;
}
#endif

#ifdef OLED_ENABLE

// Used to draw on to the oled screen
bool oled_task_user(void) {
    //render_anim();  // renders pixelart

    oled_set_cursor(0, 0);                          // sets cursor to (row, column) using charactar spacing (5 rows on 128x32 screen, anything more will overflow back to the top)
    
    update_dip_switch_state(); // Update dip switch state

    if (dip_switch_pressed) {
        switch (get_highest_layer(layer_state)) {
            case 0:
                oled_write_P(PSTR("Layer Info:\n"), false);
                oled_write_P(PSTR("DESKTOP SHORTCUTS \n"), false);
                oled_write_P(PSTR("\n"), false);
                oled_write_P(PSTR("\n"), false);

                break;
            case 1:
                oled_write_P(PSTR("Layer Info:\n"), false);
                oled_write_P(PSTR("MICROCAP \n"), false);
                oled_write_P(PSTR("\n"), false);
                oled_write_P(PSTR("\n"), false);
                break;
            case 2:
                oled_write_P(PSTR("Layer Info:\n"), false);
                oled_write_P(PSTR("ALTIUM DESIGNER\n"), false);
                oled_write_P(PSTR("\n"), false);
                oled_write_P(PSTR("\n"), false);
                break;
            case 3:
                oled_write_P(PSTR("Layer Info:\n"), false);
                oled_write_P(PSTR("RGB FUNCTIONS\n"), false);
                oled_write_P(PSTR("\n"), false);
                oled_write_P(PSTR("\n"), false);
                break;
            case 5:
                oled_write_P(PSTR("Layer Info:\n"), false);
                oled_write_P(PSTR("TEAMS\n"), false);
                oled_write_P(PSTR("\n"), false);
                oled_write_P(PSTR("\n"), false);
                break;
            default:
                oled_write_P(PSTR("Layer Info:\n"), false);
                oled_write_P(PSTR("MATHCAD\n"), false);
                oled_write_P(PSTR("\n"), false);
                oled_write_P(PSTR("\n"), false);
                break;
        }

    }else{

    switch (get_highest_layer(layer_state)) {
        case 2: 
                      
             oled_write_P(PSTR("BRD_O BRD_CT POLY_CR\n"), false);
             oled_write_P(PSTR("SHLV  RPOURs RESTORE\n"), false);
             oled_write_P(PSTR("T_VIA T_WDTH T_SGNL\n"), false);
             oled_write_P(PSTR("ROUTE   ESC   LAYER\n"), false);
             
            break;
        case 0:
            oled_write_P(PSTR("PULSE  EDGE   FILE\n"), false);
            oled_write_P(PSTR("TEAMS ALTIUM PRNTSCR\n"), false);
            oled_write_P(PSTR("uCrAP  CALC    SAP\n"), false);
            oled_write_P(PSTR("FLDSTR SW_DSPL  \n"), false);
            break;
        case 3:
            oled_write_P(PSTR("BRT+ BRT- \n"), false);
            oled_write_P(PSTR("     BREATH  XMAS\n"), false);
            oled_write_P(PSTR("CYCL FULL    SNK\n"), false);
            oled_write_P(PSTR("     FOLLOW STAR\n"), false);
            break;
        case 1:
            oled_write_P(PSTR("TRAN  DYN_DC ENTR\n"), false);
            oled_write_P(PSTR("Z_IN  Z_OUT  AUTO\n"), false);
            oled_write_P(PSTR("EXIT  STEP\n"), false);
            oled_write_P(PSTR("      PREV  TRGT_HRS\n"), false);
            break;
        case 4:
            oled_write_P(PSTR("SUBSPT  EXP    SQRT\n"), false);
            oled_write_P(PSTR("UNITS   OPRTOR SYMB\n"), false);
            oled_write_P(PSTR("B_EQ    EVAL   DEF\n"), false);
            oled_write_P(PSTR("CALC    LABEL \n"), false);
            break;
        case 5:
            oled_write_P(PSTR("VUKICA VMAIL SEARCH\n"), false);
            oled_write_P(PSTR(" \n"), false);
            oled_write_P(PSTR("\n"), false);
            oled_write_P(PSTR("MUTE        ENDCALL \n"), false);
            break;
        default:
            // Or use the write_ln shortcut over adding '\n' to the end of your string
            oled_write_ln_P(PSTR("Undefined"), false);
    }}

    return false;
}
#endif
