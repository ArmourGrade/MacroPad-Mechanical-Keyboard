/*
Copyright 2020 imchipwood
This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 2 of the License, or
(at your option) any later version.
This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.
*/
#pragma once

/* Reduce tapdance required taps from 5 to 2 */
#define TAPPING_TOGGLE 2
#define DIP_SWITCH_PINS { D4, C6 }
#define WS2812_DI_PIN	B6
//#define RGBLED_NUM 18
#define RGBLIGHT_LED_COUNT 18 //ovo je stavljeno zbog rp2040
//#define DEBOUNCE 5
#define USB_SUSPEND_WAKEUP_DELAY 5000
#define RGBLIGHT_EFFECT_BREATHING
//#define RGBLIGHT_EFFECT_ALTERNATING
#define RGBLIGHT_EFFECT_SNAKE
//#define RGBLIGHT_EFFECT_RAINBOW_MOOD
//#define RGBLIGHT_EFFECT_RAINBOW_SWIRL
//#define RGBLIGHT_EFFECT_KNIGHT
#define RGBLIGHT_EFFECT_TWINKLE
//#define RGBLIGHT_EFFECT_STATIC_GRADIENT
#define RGB_MATRIX_SLEEP
#define RGBLIGHT_DEFAULT_VAL	140
//#define RGBLIGHT_EFFECT_CHRISTMAS
#define USB_MAX_POWER_CONSUMPTION 500
#define RGBLIGHT_LIMIT_VAL 140
#define OLED_DISPLAY_128X64